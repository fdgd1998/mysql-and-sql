call CARGA(); /*Se generan las incógintas*/
call OPERAR(); /*Se calucula la ecuación con cada una de las ocurrencias de la BD*/